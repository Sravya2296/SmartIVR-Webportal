package com.cts.smart.ivr.controller;

import java.io.IOException;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.cts.ivr.bean.ActivityBean;
import com.cts.ivr.bean.EmployeeClass;
import com.cts.ivr.daoImpl.ActivityMethodImpl;

/**
 * Servlet implementation class ActivityController
 */
@WebServlet("/ViewActivityController")
public class ViewActivityController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private ActivityMethodImpl methodObject;

	ActivityMethodImpl method = new ActivityMethodImpl();

	boolean status = false;

	RequestDispatcher dispatcher;

	@Resource(name = "jdbc/smart_ivr")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			methodObject = new ActivityMethodImpl(dataSource);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			System.out.println("doGet method of ViewActivityController");
			request.getRequestDispatcher("/StartUp.jsp").forward(request, response);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			System.out.println("doPost method of ViewActivityController");
			// listEmpActivity(request, response);
			ActivityList(request, response);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	private void ActivityList(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String fromDate = request.getParameter("fromDate");
		String toDate = request.getParameter("toDate");
		String customer = request.getParameter("customer");

		List<ActivityBean> activity = methodObject.getActivityDetails(fromDate, toDate, customer);

		if (!(activity.isEmpty())) {
			request.setAttribute("Activity_List", activity);
			// send to JSP page (view)
			HttpSession session = request.getSession();
			session.setAttribute("user", activity);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/list-activity.jsp");
			dispatcher.include(request, response);
		} else {
			// add activity to the request
			System.out.println("Activity_List" + activity);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/NoActivityPage.jsp");
			dispatcher.forward(request, response);
		}
	}
}
