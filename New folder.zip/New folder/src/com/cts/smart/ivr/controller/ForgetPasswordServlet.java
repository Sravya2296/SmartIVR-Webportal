package com.cts.smart.ivr.controller;

import java.io.IOException;
import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import com.cts.ivr.daoImpl.ActivityMethodImpl;

@WebServlet("/ForgetPasswordServlet")
public class ForgetPasswordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ForgetPasswordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	private ActivityMethodImpl methodObject;

	ActivityMethodImpl method = new ActivityMethodImpl();

	boolean status = false;

	RequestDispatcher dispatcher;

	@Resource(name = "jdbc/smart_ivr")
	private DataSource dataSource;

	@Override
	public void init() throws ServletException {
		super.init();
		try {
			methodObject = new ActivityMethodImpl(dataSource);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		try {
			System.out.println("doGet method of SendMailServlet");
			String action = request.getServletPath();
			// String theCommand = request.getParameter("command");
			System.out.println("action in doGet method is " + action);
			// request.getRequestDispatcher("/StartUp.jsp").forward(request, response);
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String EmpName = null;
		String password = null;
		try {
			System.out.println("doPost method of SendMailServlet");
			String email = request.getParameter("email");
			System.out.println("Entered email id for forgot password is " + email);

			boolean status = methodObject.emailValidation(email);
			if (status) {
				System.out.println("Email validation successful");
				request.setAttribute("success", "Login successful");
				EmpName = methodObject.getEmployeeName(email);
				password = methodObject.getPassword(email);
				methodObject.sendMail(EmpName, password, email);
				dispatcher = request.getRequestDispatcher("/Login.jsp");
				dispatcher.forward(request, response);
			} else {
				System.out.println("Email not found");
				request.setAttribute("<h1> style='red' errorMessage", "Invalid Email id </h1>");
				// out.print(<html><h1> "Sorry, email or password is wrong" </h1></html>);
				request.setAttribute("errorMessage", "Invalid user or password");
				dispatcher = request.getRequestDispatcher("/Forgotpassword.jsp");
				dispatcher.forward(request, response);
			}
		} catch (Exception exc) {
			throw new ServletException(exc);
		}
	}
}
