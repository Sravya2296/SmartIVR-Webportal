package com.cts.ivr.dao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.ivr.bean.EmployeeClass;

public interface ActivityMethods {
	public List<EmployeeClass> getActivityDetails(String customer) throws Exception;

	public boolean loginValidation(String email, String pwd);

	public void addActivity(String date, String time, String customer, String categorization, String description)
			throws Exception;

	void sendMail(String EmpName, String password, String receiverEmail) throws Exception;

}
