package com.cts.ivr.bean;

public class ActivityBean {

	private String activitydate;
	private String activitytime;
	private String customer;
	private String categorization;
	private String description;
	private String fromDate;
	private String ToDate;

	public ActivityBean(String customer, String fromDate, String toDate) {
		super();
		this.customer = customer;
		this.fromDate = fromDate;
		ToDate = toDate;
	}

	@Override
	public String toString() {
		return "ActivityBean [activitydate=" + activitydate + ", activitytime=" + activitytime + ", customer="
				+ customer + ", categorization=" + categorization + ", description=" + description + "]";
	}

	public ActivityBean(String activitydate, String activitytime, String customer, String description) {
		this.activitydate = activitydate;
		this.activitytime = activitytime;
		this.customer = customer;
		this.description = description;
	}

	public String getactivitydate() {
		return activitydate;
	}

	public void setactivitydate(String activitydate) {
		this.activitydate = activitydate;
	}

	public String getactivitytime() {
		return activitytime;
	}

	public void setactivitytime(String activitytime) {
		this.activitytime = activitytime;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCategorization() {
		return categorization;
	}

	public void setCategorization(String categorization) {
		this.categorization = categorization;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
